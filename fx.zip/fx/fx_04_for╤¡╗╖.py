


for i in "name":
    if i == 'm':
        continue
    print(i)
else:
    print('输出完毕')