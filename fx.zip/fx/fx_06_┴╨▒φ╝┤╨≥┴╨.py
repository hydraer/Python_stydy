# 列表可一次性存储多个有序数据，且可为不同数据类型

list1 = ['hello', '1', 2, True, 2]

# 一、查找
# 返回指定数据的下标
print(list1.index(True))
# 统计指定数据在序列中出现的次数
print(list1.count(2))
# 统计列表长度，即列表中数据个数
print(len(list1))
# 判断数据是否在列表里
print('hello' not in list1)